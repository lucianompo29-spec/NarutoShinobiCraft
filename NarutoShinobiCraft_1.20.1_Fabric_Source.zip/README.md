# Naruto Shinobi Craft — Minecraft Java 1.20.1

Primeira base jogável (Fabric) do projeto. Este ZIP contém **código-fonte**, não um `.jar` compilado.

## O que esta versão inicial inclui
- Base Fabric para Minecraft Java 1.20.1 / Java 17.
- HUD com chakra, Sharingan, Susanoo e indicador de visão comprometida.
- Chakra inicial 100/100 e regeneração de 1 ponto por segundo.
- Tecla G para ligar/desligar o Sharingan.
- Teclas L e R para poderes oculares de demonstração.
- L + R simultaneamente para tentar ativar/desativar o Susanoo (bloqueado até o Mangekyō ser desbloqueado).
- Tecla V para um Rasengan inicial que causa dano a um mob próximo.
- Comandos `/nsc chakra`, `/nsc chakra reset`, `/nsc vision reset` e `/nsc dev mangekyo` (teste de operador).

## Importante
- Ainda não é a versão definitiva: os poderes oculares, evolução de tomoe, missões, clãs, jutsus completos, clones reais, modelos/texturas do Susanoo, itens e persistência de dados serão desenvolvidos nas próximas etapas.
- O estado de chakra e os doujutsu desta base é temporário e ainda não persiste após sair do mundo/servidor.
- L/R podem conflitar com atalhos de outras modificações; podem ser remapeados em Opções > Controles.
- O comando de reset requer permissão de operador.
- O código ainda precisa ser compilado e testado em uma instalação Fabric 1.20.1.

## Compilar
1. Instale Java 17 e Gradle (ou abra com um ambiente Gradle compatível).
2. Na pasta do projeto, execute `gradle build`.
3. O arquivo JAR será gerado em `build/libs/`.

Dependências Gradle precisam ser baixadas da internet na primeira compilação.
