package br.com.nsc.network;

import br.com.nsc.NarutoShinobiCraft;
import br.com.nsc.system.ChakraManager;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public final class NSCNetworking {
    public static final Identifier ACTION = new Identifier(NarutoShinobiCraft.MOD_ID, "action");
    public static final Identifier HUD = new Identifier(NarutoShinobiCraft.MOD_ID, "hud");

    private NSCNetworking() {}

    public static void registerServerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(ACTION, (server, player, handler, buf, responseSender) -> {
            String action = buf.readString(32);
            server.execute(() -> {
                switch (action) {
                    case "sharingan" -> ChakraManager.toggleSharingan(player);
                    case "left_eye" -> ChakraManager.ocularPower(player, "L");
                    case "right_eye" -> ChakraManager.ocularPower(player, "R");
                    case "susanoo" -> ChakraManager.toggleSusanoo(player);
                    case "rasengan" -> ChakraManager.castRasengan(player);
                    default -> player.sendMessage(net.minecraft.text.Text.literal("Acao desconhecida."), true);
                }
            });
        });
    }

    public static void sendHud(ServerPlayerEntity player, ChakraManager.State state) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(state.chakra);
        buf.writeInt(state.maxChakra);
        buf.writeBoolean(state.sharinganActive);
        buf.writeBoolean(state.susanooActive);
        buf.writeInt(state.vision);
        ServerPlayNetworking.send(player, HUD, buf);
    }
}
