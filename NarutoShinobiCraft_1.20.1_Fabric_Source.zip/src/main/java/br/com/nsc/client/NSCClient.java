package br.com.nsc.client;

import br.com.nsc.NarutoShinobiCraft;
import br.com.nsc.network.NSCNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import org.lwjgl.glfw.GLFW;

public class NSCClient implements ClientModInitializer {
    private static KeyBinding sharinganKey;
    private static KeyBinding leftKey;
    private static KeyBinding rightKey;
    private static KeyBinding rasenganKey;
    private static int chakra = 100;
    private static int maxChakra = 100;
    private static boolean sharingan = false;
    private static boolean susanoo = false;
    private static int vision = 0;
    private static boolean comboLatch = false;

    @Override
    public void onInitializeClient() {
        sharinganKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nsc.sharingan", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.nsc"));
        leftKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nsc.left_eye", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_L, "category.nsc"));
        rightKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nsc.right_eye", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.nsc"));
        rasenganKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nsc.rasengan", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.nsc"));

        ClientPlayNetworking.registerGlobalReceiver(NSCNetworking.HUD, (client, handler, buf, responseSender) -> {
            int c = buf.readInt();
            int m = buf.readInt();
            boolean s = buf.readBoolean();
            boolean su = buf.readBoolean();
            int v = buf.readInt();
            client.execute(() -> {
                chakra = c; maxChakra = m; sharingan = s; susanoo = su; vision = v;
            });
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            if (sharinganKey.wasPressed()) send("sharingan");

            boolean both = leftKey.isPressed() && rightKey.isPressed();
            if (both && !comboLatch) {
                send("susanoo");
                comboLatch = true;
            } else if (!both) {
                comboLatch = false;
                if (leftKey.wasPressed()) send("left_eye");
                if (rightKey.wasPressed()) send("right_eye");
            }
            while (rasenganKey.wasPressed()) send("rasengan");
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (net.minecraft.client.MinecraftClient.getInstance().player == null) return;
            var client = net.minecraft.client.MinecraftClient.getInstance();
            int x = 8, y = 8;
            drawContext.fill(x - 3, y - 3, x + 150, y + 42, 0x99000000);
            drawContext.drawTextWithShadow(client.textRenderer,
                    "Chakra: " + chakra + "/" + maxChakra, x, y, 0x55CCFF);
            drawContext.drawTextWithShadow(client.textRenderer,
                    "Sharingan: " + (sharingan ? "ATIVO" : "desativado"), x, y + 12, sharingan ? 0xFF4444 : 0xFFFFFF);
            drawContext.drawTextWithShadow(client.textRenderer,
                    "Susanoo: " + (susanoo ? "ATIVO" : "desativado"), x, y + 24, susanoo ? 0xCC88FF : 0xFFFFFF);
            if (vision > 0) {
                int alpha = Math.min(110, vision);
                drawContext.fill(0, 0, client.getWindow().getScaledWidth(),
                        client.getWindow().getScaledHeight(), (alpha << 24) | 0x660000);
                drawContext.drawTextWithShadow(client.textRenderer,
                        "Visao comprometida: " + vision + "% (/nsc vision reset)", x, y + 36, 0xFF7777);
            }
        });
    }

    private static void send(String action) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(action);
        ClientPlayNetworking.send(NSCNetworking.ACTION, buf);
    }
}
