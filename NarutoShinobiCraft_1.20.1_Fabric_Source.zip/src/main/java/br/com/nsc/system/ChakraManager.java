package br.com.nsc.system;

import br.com.nsc.network.NSCNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Initial session state for chakra and doujutsu.
 * Persistent saving and multiplayer balancing are planned for a later build.
 */
public final class ChakraManager {
    private static final Map<UUID, State> STATES = new ConcurrentHashMap<>();

    private ChakraManager() {}

    private static State state(ServerPlayerEntity player) {
        return STATES.computeIfAbsent(player.getUuid(), id -> new State());
    }

    public static int getChakra(ServerPlayerEntity player) { return state(player).chakra; }
    public static int getMaxChakra(ServerPlayerEntity player) { return state(player).maxChakra; }
    public static int getVision(ServerPlayerEntity player) { return state(player).vision; }
    public static boolean isSharinganActive(ServerPlayerEntity player) { return state(player).sharinganActive; }
    public static boolean isSusanooActive(ServerPlayerEntity player) { return state(player).susanooActive; }

    public static void reset(ServerPlayerEntity player) {
        State s = state(player);
        s.chakra = s.maxChakra;
        sync(player);
    }

    public static void resetVision(ServerPlayerEntity player) {
        State s = state(player);
        s.vision = 0;
        sync(player);
    }

    public static void toggleSharingan(ServerPlayerEntity player) {
        State s = state(player);
        if (!s.sharinganActive && s.chakra < 1) {
            player.sendMessage(net.minecraft.text.Text.literal("Sem chakra suficiente para ativar o Sharingan."), true);
            return;
        }
        s.sharinganActive = !s.sharinganActive;
        if (!s.sharinganActive) s.susanooActive = false;
        player.sendMessage(net.minecraft.text.Text.literal(
                s.sharinganActive ? "Sharingan ativado." : "Sharingan desativado."), true);
        sync(player);
    }

    public static void ocularPower(ServerPlayerEntity player, String eye) {
        State s = state(player);
        if (!s.sharinganActive) {
            player.sendMessage(net.minecraft.text.Text.literal("Ative o Sharingan primeiro."), true);
            return;
        }
        int cost = 5;
        if (s.chakra < cost) {
            player.sendMessage(net.minecraft.text.Text.literal("Chakra insuficiente."), true);
            return;
        }
        s.chakra -= cost;
        // Placeholder progression: each MS ocular activation increases blur.
        if (s.mangekyo) s.vision = Math.min(100, s.vision + 12);
        player.sendMessage(net.minecraft.text.Text.literal(
                "Poder ocular " + eye + " usado (-" + cost + " chakra)."), true);
        sync(player);
    }

    public static void toggleSusanoo(ServerPlayerEntity player) {
        State s = state(player);
        if (!s.mangekyo) {
            player.sendMessage(net.minecraft.text.Text.literal(
                    "O Susanoo exige o Mangekyo e sera desbloqueado pela progressao do mod."), true);
            return;
        }
        if (!s.susanooActive && s.chakra < 20) {
            player.sendMessage(net.minecraft.text.Text.literal("Precisas de 20 de chakra para o Susanoo."), true);
            return;
        }
        s.susanooActive = !s.susanooActive;
        if (s.susanooActive) s.chakra -= 20;
        player.sendMessage(net.minecraft.text.Text.literal(
                s.susanooActive ? "Susanoo ativado! (forma inicial planejada)" : "Susanoo desativado."), true);
        sync(player);
    }

    public static void castRasengan(ServerPlayerEntity player) {
        State s = state(player);
        int cost = 20;
        if (s.chakra < cost) {
            player.sendMessage(net.minecraft.text.Text.literal("Chakra insuficiente para Rasengan."), true);
            return;
        }
        s.chakra -= cost;
        var target = player.getWorld().getOtherEntities(player,
                player.getBoundingBox().expand(4.0),
                entity -> entity instanceof net.minecraft.entity.mob.MobEntity
                        && entity.isAlive() && player.canSee(entity))
                .stream().min(java.util.Comparator.comparingDouble(player::squaredDistanceTo)).orElse(null);
        if (target != null) {
            target.damage(player.getDamageSources().playerAttack(player), 8.0f);
            target.addVelocity(0, 0.45, 0);
            target.velocityModified = true;
            player.getWorld().addParticle(net.minecraft.particle.ParticleTypes.CLOUD,
                    target.getX(), target.getY() + 1, target.getZ(), 0.2, 0.2, 0.2);
            player.sendMessage(net.minecraft.text.Text.literal("Rasengan acertou o alvo! (-20 chakra)"), true);
        } else {
            player.sendMessage(net.minecraft.text.Text.literal("Rasengan usado, mas nenhum mob estava proximo. (-20 chakra)"), true);
        }
        sync(player);
    }

    public static void toggleMangekyoForTesting(ServerPlayerEntity player) {
        // Temporary developer/testing toggle; not exposed to ordinary players.
        State s = state(player);
        s.mangekyo = !s.mangekyo;
        sync(player);
    }

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            State s = state(player);
            if (s.chakra < s.maxChakra && player.age % 20 == 0) s.chakra++;
            if (s.sharinganActive && player.age % 20 == 0) {
                int cost = s.mangekyo ? 5 : 1;
                s.chakra = Math.max(0, s.chakra - cost);
                if (s.chakra == 0) {
                    s.sharinganActive = false;
                    s.susanooActive = false;
                    player.sendMessage(net.minecraft.text.Text.literal("Chakra esgotado: Sharingan desativado."), true);
                }
            }
            if (s.susanooActive && player.age % 20 == 0) {
                s.chakra = Math.max(0, s.chakra - 3);
                if (s.chakra == 0) {
                    s.susanooActive = false;
                    player.sendMessage(net.minecraft.text.Text.literal("Chakra esgotado: Susanoo desativado."), true);
                }
            }
            if (player.age % 10 == 0) sync(player);
        }
    }

    public static void sync(ServerPlayerEntity player) {
        NSCNetworking.sendHud(player, state(player));
    }

    public static class State {
        public int chakra = 100;
        public int maxChakra = 100;
        public int vision = 0;
        public boolean sharinganActive = false;
        public boolean susanooActive = false;
        public boolean mangekyo = false;
    }
}
