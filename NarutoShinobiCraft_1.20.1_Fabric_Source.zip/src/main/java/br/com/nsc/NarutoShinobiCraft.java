package br.com.nsc;

import br.com.nsc.network.NSCNetworking;
import br.com.nsc.system.ChakraManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.server.network.ServerPlayerEntity;

public class NarutoShinobiCraft implements ModInitializer {
    public static final String MOD_ID = "naruto_shinobi_craft";

    @Override
    public void onInitialize() {
        NSCNetworking.registerServerReceivers();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                ChakraManager.sync((ServerPlayerEntity) handler.player));

        ServerTickEvents.END_SERVER_TICK.register(ChakraManager::tick);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("nsc")
                .then(CommandManager.literal("chakra")
                    .executes(ctx -> {
                        ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                        ctx.getSource().sendFeedback(() -> Text.literal(
                            "Chakra: " + ChakraManager.getChakra(player) + "/" + ChakraManager.getMaxChakra(player)), false);
                        return 1;
                    })
                    .then(CommandManager.literal("reset").requires(source -> source.hasPermissionLevel(2))
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            ChakraManager.reset(player);
                            ctx.getSource().sendFeedback(() -> Text.literal("Chakra restaurado."), false);
                            return 1;
                        })))
                .then(CommandManager.literal("vision")
                    .then(CommandManager.literal("reset").requires(source -> source.hasPermissionLevel(2))
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            ChakraManager.resetVision(player);
                            ctx.getSource().sendFeedback(() -> Text.literal("Desfoque do Mangekyo removido."), false);
                            return 1;
                        })))
                .then(CommandManager.literal("dev").requires(source -> source.hasPermissionLevel(2))
                    .then(CommandManager.literal("mangekyo")
                        .executes(ctx -> {
                            ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                            ChakraManager.toggleMangekyoForTesting(player);
                            ctx.getSource().sendFeedback(() -> Text.literal("Modo de teste do Mangekyo alternado."), false);
                            return 1;
                        })))
                .then(CommandManager.literal("help")
                    .executes(ctx -> {
                        ctx.getSource().sendFeedback(() -> Text.literal(
                            "NSC: /nsc chakra | /nsc chakra reset | /nsc vision reset. Teclas L/R: poderes oculares; L+R: Susanoo."), false);
                        return 1;
                    }))
            );
        });
    }
}
